package com.example.semana2registro;

import androidx.appcompat.app.AppCompatActivity;

import android.app.DatePickerDialog;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;

import java.util.Calendar;

public class MainActivity extends AppCompatActivity implements View.OnClickListener {
    Button bfecha, bsig;
    private EditText efecha,NomCom,etel,eemail,edes;
    private int dia,mes,año;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        NomCom= (EditText)findViewById(R.id.NomCom);
        etel=(EditText)findViewById(R.id.eTel);
        eemail=(EditText)findViewById(R.id.eEmail);
        edes=(EditText)findViewById(R.id.eDes);


        bfecha =(Button)findViewById(R.id.bfecha);
        efecha=(EditText) findViewById(R.id.efecha);

        bfecha.setOnClickListener(this);

        
    }

    //MetodoBotonSiguiente
    public void Siguiente(View view){
        Intent siguiente = new Intent(this, SegundoActivity.class);
        siguiente.putExtra("datoNom",NomCom.getText().toString());
        siguiente.putExtra("datoTele",etel.getText().toString());
        siguiente.putExtra("datoFecha",efecha.getText().toString());
        siguiente.putExtra("datoEmail",eemail.getText().toString());
        siguiente.putExtra("datoDes",edes.getText().toString());


        startActivity(siguiente);
    }

    @Override
    public void onClick(View v) {
        if (v==bfecha){
            final Calendar c = Calendar.getInstance();
            dia = c.get(Calendar.DAY_OF_MONTH);
            mes = c.get(Calendar.MONTH);
            año = c.get(Calendar.YEAR);


            DatePickerDialog datePickerDialog = new DatePickerDialog(this, new DatePickerDialog.OnDateSetListener() {
                @Override
                public void onDateSet(DatePicker view, int year, int month, int dayOfMonth) {
                    efecha.setText(dayOfMonth+"/"+(month+1)+"/"+year);
                }
            }
            ,dia,mes,año);
            datePickerDialog.show();
        }
    }
}
