package com.example.semana2registro;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

public class SegundoActivity extends AppCompatActivity {

    private TextView eConfNom,eConfTel,eConfEmail,eFechaN,eConfDes;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_segundo);

        eConfNom = (TextView)findViewById(R.id.eConfNom);
        eConfTel = (TextView)findViewById(R.id.eConfTel);
        eConfEmail =(TextView)findViewById(R.id.eConfEmail);
        eFechaN = (TextView)findViewById(R.id.eFechaN);
        eConfDes =(TextView)findViewById(R.id.eConfDes);

        String datoFecha = getIntent().getStringExtra("datoFecha");
        eFechaN.setText(datoFecha);

        String datoDes = getIntent().getStringExtra("datoDes");
        eConfDes.setText(datoDes);

        String datoEmail = getIntent().getStringExtra("datoEmail");
        eConfEmail.setText(datoEmail);

        String datoTele = getIntent().getStringExtra("datoTele");
        eConfTel.setText(datoTele);

        String datoNom = getIntent().getStringExtra("datoNom");
        eConfNom.setText(datoNom);


    }


    //Metodo para el boton Anterior
    public void Regreso(View view){
        Intent regreso = new Intent(this, MainActivity.class);
        startActivity(regreso);

    }
}
